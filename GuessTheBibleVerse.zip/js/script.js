const clues = [
    { clue: "For God so loved the world…", answer: "John 3:16", type: "type" },
    { clue: "The Lord is my shepherd…", answer: "Psalm 23:1", type: "type" },
    { clue: "I can do all things…", answer: "Philippians 4:13", type: "type" },
    { clue: "In the beginning…", answer: "Genesis 1:1", type: "type" },
    { clue: "Your word is a lamp to my feet…", choices: ["Proverbs 3:5", "Psalm 119:105", "Matthew 5:14"], answer: "Psalm 119:105", type: "mc" }
];

let current = 0;
let score = 0;
let mode = "type";

function startGame(selectedMode) {
    document.getElementById("home").style.display = "none";
    document.getElementById("game").style.display = "block";
    score = 0;
    current = 0;
    mode = selectedMode;
    document.getElementById("score").textContent = score;
    nextClue();
}

function nextClue() {
    const clue = clues.find(c => c.type === mode && (Math.random() > 0.5 || c.choices));
    if (!clue) return;
    document.getElementById("clue").textContent = "Clue: " + clue.clue;
    document.getElementById("feedback").textContent = "";
    const inputArea = document.getElementById("inputArea");
    inputArea.innerHTML = "";

    if (mode === "type") {
        inputArea.innerHTML = '<input type="text" id="answerInput" placeholder="Your answer" /> <button onclick="checkAnswer()">Submit</button>';
    } else {
        clue.choices.forEach(choice => {
            const btn = document.createElement("button");
            btn.textContent = choice;
            btn.onclick = () => checkAnswer(choice);
            inputArea.appendChild(btn);
        });
    }

    window.currentClue = clue;
}

function checkAnswer(userInput = null) {
    const userAnswer = userInput || document.getElementById("answerInput").value.trim();
    const correct = window.currentClue.answer.toLowerCase() === userAnswer.toLowerCase();
    const feedback = document.getElementById("feedback");
    if (correct) {
        score++;
        feedback.textContent = "Correct!";
    } else {
        feedback.textContent = "Wrong! Answer: " + window.currentClue.answer;
    }
    document.getElementById("score").textContent = score;
    if (score >= 10) {
        feedback.textContent += " You win!";
        document.getElementById("inputArea").innerHTML = "<button onclick='startGame(mode)'>Play Again</button>";
    }
}
